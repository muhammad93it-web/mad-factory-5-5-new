import { Router } from "express";
import { and, sql, desc, eq } from "drizzle-orm";
import {
  db,
  salesInvoicesTable,
  customerPaymentsTable,
  purchaseInvoicesTable,
  supplierPaymentsTable,
  payrollEntriesTable,
  expensesTable,
  incomesTable,
  shareholderTransactionsTable,
  shareholdersTable,
  exchangeRatesTable,
} from "@workspace/db";
import {
  GetCashboxSummaryQueryParams,
  GetMonthlyReportQueryParams,
  GetProfitLossReportQueryParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/cashbox/summary", async (req, res): Promise<void> => {
  const qp = GetCashboxSummaryQueryParams.safeParse(req.query);
  const fromDate = qp.success ? qp.data.fromDate : undefined;
  const toDate = qp.success ? qp.data.toDate : undefined;

  const dateFilter = (dateCol: string) => {
    const parts = [];
    if (fromDate) parts.push(sql.raw(`${dateCol} >= '${fromDate}'`));
    if (toDate) parts.push(sql.raw(`${dateCol} <= '${toDate}'`));
    return parts;
  };

  const [salesAgg] = await db.select({ total: sql<string>`coalesce(sum(paid_amount), 0)` }).from(salesInvoicesTable).where(and(eq(salesInvoicesTable.isDeleted, false), ...dateFilter("invoice_date")));
  const [custPayAgg] = await db.select({ total: sql<string>`coalesce(sum(amount), 0)` }).from(customerPaymentsTable).where(and(...dateFilter("payment_date")));
  const [purchAgg] = await db.select({ total: sql<string>`coalesce(sum(paid_amount_iqd), 0)` }).from(purchaseInvoicesTable).where(and(eq(purchaseInvoicesTable.isDeleted, false), ...dateFilter("invoice_date")));
  const [suppPayAgg] = await db.select({ total: sql<string>`coalesce(sum(amount_iqd), 0)` }).from(supplierPaymentsTable).where(and(...dateFilter("payment_date")));
  const [payrollAgg] = await db.select({ total: sql<string>`coalesce(sum(paid_amount), 0)` }).from(payrollEntriesTable);
  const [expAgg] = await db.select({ total: sql<string>`coalesce(sum(amount), 0)` }).from(expensesTable).where(and(...dateFilter("expense_date")));
  const [incAgg] = await db.select({ total: sql<string>`coalesce(sum(amount), 0)` }).from(incomesTable).where(and(...dateFilter("income_date")));
  const [shrWithdrawAgg] = await db.select({ total: sql<string>`coalesce(sum(amount), 0)` }).from(shareholderTransactionsTable).where(and(eq(shareholderTransactionsTable.type, "withdrawal"), ...dateFilter("transaction_date")));

  const [custDebtAgg] = await db.select({ total: sql<string>`coalesce(sum(remaining_debt), 0)` }).from(salesInvoicesTable).where(eq(salesInvoicesTable.isDeleted, false));
  const [suppDebtAgg] = await db.select({ total: sql<string>`coalesce(sum(remaining_debt_iqd), 0)` }).from(purchaseInvoicesTable).where(eq(purchaseInvoicesTable.isDeleted, false));
  const [latestRate] = await db.select().from(exchangeRatesTable).orderBy(desc(exchangeRatesTable.rateDate)).limit(1);

  const totalSalesRevenue = Number(salesAgg.total);
  const totalCustomerPayments = Number(custPayAgg.total);
  const totalPurchasesPaid = Number(purchAgg.total);
  const totalSupplierPayments = Number(suppPayAgg.total);
  const totalPayroll = Number(payrollAgg.total);
  const totalExpenses = Number(expAgg.total);
  const totalOtherIncome = Number(incAgg.total);
  const totalShareholderWithdrawals = Number(shrWithdrawAgg.total);

  const cashIn = totalSalesRevenue + totalCustomerPayments + totalOtherIncome;
  const cashOut = totalPurchasesPaid + totalSupplierPayments + totalPayroll + totalExpenses + totalShareholderWithdrawals;

  res.json({
    fromDate: fromDate ?? null,
    toDate: toDate ?? null,
    totalSalesRevenue,
    totalCustomerPayments,
    totalPurchasesPaid,
    totalSupplierPayments,
    totalPayroll,
    totalExpenses,
    totalOtherIncome,
    totalShareholderWithdrawals,
    cashIn,
    cashOut,
    netCash: cashIn - cashOut,
    totalCustomerDebt: Number(custDebtAgg.total),
    totalSupplierDebt: Number(suppDebtAgg.total),
    latestExchangeRate: latestRate ? Number(latestRate.rate) : null,
  });
});

router.get("/cashbox/monthly-report", async (req, res): Promise<void> => {
  const qp = GetMonthlyReportQueryParams.safeParse(req.query);
  const now = new Date();
  const year = (qp.success && qp.data.year) ? qp.data.year : now.getFullYear();
  const month = (qp.success && qp.data.month) ? qp.data.month : String(now.getMonth() + 1).padStart(2, "0");
  const prefix = `${year}-${String(month).padStart(2, "0")}`;

  const [salesAgg] = await db.select({ total: sql<string>`coalesce(sum(total), 0)` }).from(salesInvoicesTable).where(and(eq(salesInvoicesTable.isDeleted, false), sql`invoice_date like ${prefix + "%"}`));
  const [purchAgg] = await db.select({ total: sql<string>`coalesce(sum(total_iqd), 0)` }).from(purchaseInvoicesTable).where(and(eq(purchaseInvoicesTable.isDeleted, false), sql`invoice_date like ${prefix + "%"}`));
  const [expAgg] = await db.select({ total: sql<string>`coalesce(sum(amount), 0)` }).from(expensesTable).where(sql`expense_date like ${prefix + "%"}`);
  const [payrollAgg] = await db.select({ total: sql<string>`coalesce(sum(total_due), 0)` }).from(payrollEntriesTable).where(sql`period like ${prefix + "%"}`);
  const [incAgg] = await db.select({ total: sql<string>`coalesce(sum(amount), 0)` }).from(incomesTable).where(sql`income_date like ${prefix + "%"}`);
  const [shrAgg] = await db.select({ total: sql<string>`coalesce(sum(amount), 0)` }).from(shareholderTransactionsTable).where(and(eq(shareholderTransactionsTable.type, "withdrawal"), sql`transaction_date like ${prefix + "%"}`));

  const [salesCashAgg] = await db.select({ total: sql<string>`coalesce(sum(paid_amount), 0)` }).from(salesInvoicesTable).where(and(eq(salesInvoicesTable.isDeleted, false), sql`invoice_date like ${prefix + "%"}`));
  const [purchCashAgg] = await db.select({ total: sql<string>`coalesce(sum(paid_amount_iqd), 0)` }).from(purchaseInvoicesTable).where(and(eq(purchaseInvoicesTable.isDeleted, false), sql`invoice_date like ${prefix + "%"}`));

  const totalSales = Number(salesAgg.total);
  const totalPurchases = Number(purchAgg.total);
  const totalExpenses = Number(expAgg.total);
  const totalPayroll = Number(payrollAgg.total);
  const totalOtherIncome = Number(incAgg.total);
  const totalShareholderWithdrawals = Number(shrAgg.total);
  const grossProfit = totalSales - totalPurchases;
  const netProfit = grossProfit - totalExpenses - totalPayroll + totalOtherIncome;
  const cashIn = Number(salesCashAgg.total) + totalOtherIncome;
  const cashOut = Number(purchCashAgg.total) + totalExpenses + totalPayroll + totalShareholderWithdrawals;

  res.json({
    month: String(month).padStart(2, "0"),
    year,
    totalSales,
    totalPurchases,
    totalExpenses,
    totalPayroll,
    totalOtherIncome,
    totalShareholderWithdrawals,
    grossProfit,
    netProfit,
    cashIn,
    cashOut,
    netCash: cashIn - cashOut,
  });
});

router.get("/cashbox/profit-loss", async (req, res): Promise<void> => {
  const qp = GetProfitLossReportQueryParams.safeParse(req.query);
  const fromDate = qp.success ? qp.data.fromDate : undefined;
  const toDate = qp.success ? qp.data.toDate : undefined;

  const dateFilter = (dateCol: string) => {
    const parts: ReturnType<typeof sql>[] = [];
    if (fromDate) parts.push(sql.raw(`${dateCol} >= '${fromDate}'`) as unknown as ReturnType<typeof sql>);
    if (toDate) parts.push(sql.raw(`${dateCol} <= '${toDate}'`) as unknown as ReturnType<typeof sql>);
    return parts;
  };

  const [salesAgg] = await db.select({ total: sql<string>`coalesce(sum(total), 0)` }).from(salesInvoicesTable).where(and(eq(salesInvoicesTable.isDeleted, false), ...dateFilter("invoice_date")));
  const [purchAgg] = await db.select({ total: sql<string>`coalesce(sum(total_iqd), 0)` }).from(purchaseInvoicesTable).where(and(eq(purchaseInvoicesTable.isDeleted, false), ...dateFilter("invoice_date")));
  const [expAgg] = await db.select({ total: sql<string>`coalesce(sum(amount), 0)` }).from(expensesTable).where(and(...dateFilter("expense_date")));
  const [payrollAgg] = await db.select({ total: sql<string>`coalesce(sum(total_due), 0)` }).from(payrollEntriesTable);
  const [incAgg] = await db.select({ total: sql<string>`coalesce(sum(amount), 0)` }).from(incomesTable).where(and(...dateFilter("income_date")));
  const [shrAgg] = await db.select({ total: sql<string>`coalesce(sum(amount), 0)` }).from(shareholderTransactionsTable).where(and(eq(shareholderTransactionsTable.type, "withdrawal"), ...dateFilter("transaction_date")));
  const shareholders = await db.select().from(shareholdersTable).where(eq(shareholdersTable.isActive, true));

  const totalRevenue = Number(salesAgg.total);
  const totalCost = Number(purchAgg.total);
  const grossProfit = totalRevenue - totalCost;
  const totalExpenses = Number(expAgg.total);
  const totalPayroll = Number(payrollAgg.total);
  const otherIncome = Number(incAgg.total);
  const shareholderWithdrawals = Number(shrAgg.total);
  const netProfit = grossProfit - totalExpenses - totalPayroll + otherIncome;

  const breakdown = shareholders.map((s) => ({
    shareholderName: s.name,
    sharePercentage: Number(s.sharePercentage),
    profitShare: (netProfit * Number(s.sharePercentage)) / 100,
  }));

  res.json({
    fromDate: fromDate ?? null,
    toDate: toDate ?? null,
    totalRevenue,
    totalCost,
    grossProfit,
    totalExpenses,
    totalPayroll,
    otherIncome,
    shareholderWithdrawals,
    netProfit,
    profitByShareholdersBreakdown: breakdown,
  });
});

export default router;
