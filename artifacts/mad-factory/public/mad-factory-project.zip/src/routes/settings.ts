import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, appSettingsTable } from "@workspace/db";
import { UpdateSettingsBody } from "@workspace/api-zod";

const router = Router();

async function ensureSettings() {
  const [settings] = await db.select().from(appSettingsTable);
  if (!settings) {
    const [s] = await db.insert(appSettingsTable).values({ factoryName: "Mad Factory", factoryNameKu: "کارگەی خشتی ماد" }).returning();
    return s;
  }
  return settings;
}

router.get("/settings", async (req, res): Promise<void> => {
  const settings = await ensureSettings();
  res.json({
    ...settings,
    currentExchangeRate: settings.currentExchangeRate != null ? Number(settings.currentExchangeRate) : null,
    updatedAt: settings.updatedAt.toISOString(),
  });
});

router.patch("/settings", async (req, res): Promise<void> => {
  const parsed = UpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const existing = await ensureSettings();
  const [s] = await db.update(appSettingsTable).set(parsed.data).where(eq(appSettingsTable.id, existing.id)).returning();
  res.json({
    ...s,
    currentExchangeRate: s.currentExchangeRate != null ? Number(s.currentExchangeRate) : null,
    updatedAt: s.updatedAt.toISOString(),
  });
});

export default router;
