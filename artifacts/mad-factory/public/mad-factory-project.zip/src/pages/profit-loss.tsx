import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/format";
import { useGetProfitLossReport } from "@workspace/api-client-react";
import { FileText, TrendingUp, TrendingDown, Users, Printer, FileSpreadsheet } from "lucide-react";
import { exportTableToExcel } from "@/lib/export";
import { PrintStyles } from "@/components/print-styles";

export default function ProfitLoss() {
  const today = new Date();
  const [fromDate, setFromDate] = useState(`${today.getFullYear()}-01-01`);
  const [toDate, setToDate] = useState(today.toISOString().split("T")[0]);
  const [applied, setApplied] = useState({ from: fromDate, to: toDate });

  const { data: report, isLoading } = useGetProfitLossReport(
    { fromDate: applied.from, toDate: applied.to },
    { query: { queryKey: ["profitLoss", applied.from, applied.to] } }
  );

  const handleExport = () => {
    if (!report) return;
    const totalProfitBeforeSalary = (report.netProfit ?? 0) + (report.totalPayroll ?? 0);
    const summaryRows = [
      ["داهاتی فرۆشتن", report.totalRevenue],
      ["قازانجی خام", report.grossProfit],
      ["داهاتی تر", report.otherIncome],
      ["خەرجیەکان", report.totalExpenses],
      ["مووچەکان", report.totalPayroll],
      ["قازانجی سافی", report.netProfit],
    ]
      .map(([k, v]) => `<tr><th>${k}</th><td>${(v ?? 0).toLocaleString()}</td></tr>`)
      .join("");
    const beforeRows = (report.profitByShareholdersBreakdown ?? [])
      .map((s) => {
        const share = (totalProfitBeforeSalary * (s.sharePercentage ?? 0)) / 100;
        return `<tr><td>${s.shareholderName}</td><td>${s.sharePercentage}%</td><td>${share.toLocaleString()}</td></tr>`;
      })
      .join("");
    const afterRows = (report.profitByShareholdersBreakdown ?? [])
      .map((s) => `<tr><td>${s.shareholderName}</td><td>${s.sharePercentage}%</td><td>${(s.profitShare ?? 0).toLocaleString()}</td></tr>`)
      .join("");
    const html = `
      <h2>ڕاپۆرتی قازانج و زیان (${applied.from} → ${applied.to})</h2>
      <h3>پوختە</h3><table>${summaryRows}</table>
      <h3>دابەشکردن — پێش مووچە (کۆ: ${totalProfitBeforeSalary.toLocaleString()})</h3>
      <table><thead><tr><th>شریک</th><th>ڕێژە</th><th>بەش</th></tr></thead><tbody>${beforeRows}</tbody></table>
      <h3>دابەشکردن — دوای مووچە (کۆ: ${(report.netProfit ?? 0).toLocaleString()})</h3>
      <table><thead><tr><th>شریک</th><th>ڕێژە</th><th>بەش</th></tr></thead><tbody>${afterRows}</tbody></table>
    `;
    exportTableToExcel(`profit-loss-${applied.from}_${applied.to}.xls`, html);
  };

  return (
    <div className="space-y-6">
      <PrintStyles />
      <div className="flex items-center justify-between flex-wrap gap-4 print:hidden">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <FileText className="h-6 w-6 text-primary" />
          ڕاپۆرتی قازانج و زیان
        </h1>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <Label className="text-sm">لە:</Label>
            <Input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="w-36" />
          </div>
          <div className="flex items-center gap-2">
            <Label className="text-sm">تا:</Label>
            <Input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="w-36" />
          </div>
          <Button onClick={() => setApplied({ from: fromDate, to: toDate })}>دووپاتکردنەوە</Button>
          <Button variant="outline" onClick={() => window.print()} className="gap-2">
            <Printer className="h-4 w-4" /> چاپکردن
          </Button>
          <Button onClick={handleExport} className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white">
            <FileSpreadsheet className="h-4 w-4" /> ئێکسڵ
          </Button>
        </div>
      </div>
      <div className="hidden print:block text-center pb-3 border-b">
        <div className="text-xl font-bold">کارگەی خشتی ماد — ڕاپۆرتی قازانج و زیان</div>
        <div className="text-xs text-slate-500 mt-1" dir="ltr">{applied.from} → {applied.to}</div>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-slate-500">بەڕێکردن...</div>
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="border-r-4 border-r-emerald-500">
              <CardContent className="pt-4">
                <div className="text-sm text-slate-500 mb-1">کۆی داهات</div>
                <div className="text-2xl font-bold text-emerald-600">{formatMoney(report?.totalRevenue)}</div>
              </CardContent>
            </Card>
            <Card className="border-r-4 border-r-red-500">
              <CardContent className="pt-4">
                <div className="text-sm text-slate-500 mb-1">کۆی لێچوون</div>
                <div className="text-2xl font-bold text-red-600">{formatMoney((report?.totalCost ?? 0) + (report?.totalExpenses ?? 0) + (report?.totalPayroll ?? 0))}</div>
              </CardContent>
            </Card>
            <Card className={`border-r-4 ${(report?.netProfit ?? 0) >= 0 ? 'border-r-blue-500' : 'border-r-red-600'}`}>
              <CardContent className="pt-4">
                <div className="text-sm text-slate-500 mb-1">قازانجی سافی</div>
                <div className={`text-2xl font-bold ${(report?.netProfit ?? 0) >= 0 ? 'text-blue-600' : 'text-red-600'}`}>{formatMoney(report?.netProfit)}</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="border-b pb-3">
                <CardTitle className="text-base flex items-center gap-2 text-emerald-700">
                  <TrendingUp className="h-4 w-4" />
                  پوختەی داهات
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4 space-y-3">
                {[
                  { label: "داهاتی فرۆشتن", value: report?.totalRevenue },
                  { label: "قازانجی خام", value: report?.grossProfit },
                  { label: "داهاتی تر", value: report?.otherIncome },
                ].map((r) => (
                  <div key={r.label} className="flex justify-between py-2 border-b border-dashed last:border-0">
                    <span className="text-slate-600">{r.label}</span>
                    <span className="font-bold text-emerald-600">{formatMoney(r.value)}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="border-b pb-3">
                <CardTitle className="text-base flex items-center gap-2 text-red-700">
                  <TrendingDown className="h-4 w-4" />
                  پوختەی خەرجی
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4 space-y-3">
                {[
                  { label: "لێچوونی کڕین", value: report?.totalCost },
                  { label: "خەرجیەکان", value: report?.totalExpenses },
                  { label: "مووچەکان", value: report?.totalPayroll },
                  { label: "دەرکردنی شریکەکان", value: report?.shareholderWithdrawals },
                ].map((r) => (
                  <div key={r.label} className="flex justify-between py-2 border-b border-dashed last:border-0">
                    <span className="text-slate-600">{r.label}</span>
                    <span className="font-bold text-red-600">{formatMoney(r.value)}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {report?.profitByShareholdersBreakdown && report.profitByShareholdersBreakdown.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Profit BEFORE salary distribution */}
              <Card className="border-emerald-200">
                <CardHeader className="border-b pb-3 bg-emerald-50/50 dark:bg-emerald-950/20">
                  <CardTitle className="text-base flex items-center gap-2 text-emerald-700">
                    <Users className="h-4 w-4" />
                    قازانج بەش بە شریکەکان — پێش لێبڕینی مووچە
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-4 space-y-3">
                  <div className="bg-emerald-50 dark:bg-emerald-950/30 rounded-md p-3 mb-2 flex justify-between items-center">
                    <span className="text-sm text-slate-600">قازانج پێش مووچە</span>
                    <span className="font-bold text-emerald-700 text-lg">
                      {formatMoney((report.netProfit ?? 0) + (report.totalPayroll ?? 0))}
                    </span>
                  </div>
                  {report.profitByShareholdersBreakdown.map((s, i) => {
                    const totalProfitBeforeSalary = (report.netProfit ?? 0) + (report.totalPayroll ?? 0);
                    const beforeSalaryShare = (totalProfitBeforeSalary * (s.sharePercentage ?? 0)) / 100;
                    return (
                      <div key={i} className="flex justify-between items-center py-2 border-b border-dashed last:border-0">
                        <div>
                          <div className="font-medium">{s.shareholderName}</div>
                          <div className="text-xs text-slate-500">{s.sharePercentage}%</div>
                        </div>
                        <span className={`font-bold ${beforeSalaryShare >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                          {formatMoney(beforeSalaryShare)}
                        </span>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>

              {/* Profit AFTER salary distribution */}
              <Card className="border-blue-200">
                <CardHeader className="border-b pb-3 bg-blue-50/50 dark:bg-blue-950/20">
                  <CardTitle className="text-base flex items-center gap-2 text-blue-700">
                    <Users className="h-4 w-4" />
                    قازانج بەش بە شریکەکان — دوای لێبڕینی مووچە
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-4 space-y-3">
                  <div className="bg-blue-50 dark:bg-blue-950/30 rounded-md p-3 mb-2 flex justify-between items-center">
                    <span className="text-sm text-slate-600">قازانج دوای مووچە</span>
                    <span className="font-bold text-blue-700 text-lg">{formatMoney(report.netProfit)}</span>
                  </div>
                  {report.profitByShareholdersBreakdown.map((s, i) => (
                    <div key={i} className="flex justify-between items-center py-2 border-b border-dashed last:border-0">
                      <div>
                        <div className="font-medium">{s.shareholderName}</div>
                        <div className="text-xs text-slate-500">{s.sharePercentage}%</div>
                      </div>
                      <span className={`font-bold ${s.profitShare >= 0 ? "text-blue-600" : "text-red-600"}`}>
                        {formatMoney(s.profitShare)}
                      </span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
