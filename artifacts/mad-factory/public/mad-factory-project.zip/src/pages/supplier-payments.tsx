import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { formatMoney, formatDate } from "@/lib/format";
import { useListSupplierPayments, useCreateSupplierPayment, useDeleteSupplierPayment, useListSuppliers, getListSupplierPaymentsQueryKey, getListSuppliersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { CreditCard, Plus, Trash2, Search, Printer, FileSpreadsheet } from "lucide-react";
import { exportTableToExcel } from "@/lib/export";
import { PrintStyles } from "@/components/print-styles";

export default function SupplierPayments() {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({ supplierId: "", amount: "", paymentDate: new Date().toISOString().split("T")[0], notes: "" });

  const { data: payments, isLoading } = useListSupplierPayments({}, { query: { queryKey: getListSupplierPaymentsQueryKey({}) } });
  const { data: suppliers } = useListSuppliers({}, { query: { queryKey: getListSuppliersQueryKey({}) } });

  const { mutate: create, isPending: creating } = useCreateSupplierPayment({ mutation: { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListSupplierPaymentsQueryKey({}) }); queryClient.invalidateQueries({ queryKey: getListSuppliersQueryKey({}) }); setOpen(false); setForm({ supplierId: "", amount: "", paymentDate: new Date().toISOString().split("T")[0], notes: "" }); } } });
  const { mutate: del } = useDeleteSupplierPayment({ mutation: { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListSupplierPaymentsQueryKey({}) }); queryClient.invalidateQueries({ queryKey: getListSuppliersQueryKey({}) }); } } });

  const selectedSupplier = useMemo(() => suppliers?.find((s) => s.id === Number(form.supplierId)), [suppliers, form.supplierId]);

  const filtered = useMemo(() => {
    const rows = payments ?? [];
    const q = search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((p) => p.supplierName?.toLowerCase().includes(q) || p.notes?.toLowerCase().includes(q) || p.paymentDate?.includes(q));
  }, [payments, search]);

  const totalPaid = useMemo(() => filtered.reduce((s, p) => s + (p.amountIqd ?? 0), 0), [filtered]);

  const handleExport = () => {
    const head = `<tr><th>ژ</th><th>دابینکار</th><th>بەروار</th><th>بڕ (د.ع)</th><th>تێبینی</th></tr>`;
    const body = filtered.map((p, i) => `<tr><td>${i + 1}</td><td>${p.supplierName}</td><td>${p.paymentDate}</td><td>${(p.amountIqd ?? 0).toLocaleString()}</td><td>${p.notes || ""}</td></tr>`).join("");
    const foot = `<tr><th colspan="3">کۆی گشتی</th><th>${totalPaid.toLocaleString()}</th><th></th></tr>`;
    exportTableToExcel(`supplier-payments-${new Date().toISOString().split("T")[0]}.xls`, `<h2>پارەدانی دابینکاران</h2><table><thead>${head}</thead><tbody>${body}</tbody><tfoot>${foot}</tfoot></table>`);
  };

  return (
    <div className="space-y-4">
      <PrintStyles />
      <div className="flex items-center justify-between flex-wrap gap-3 print:hidden">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <CreditCard className="h-6 w-6 text-primary" />پارەدانی دابینکاران
        </h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => window.print()} className="gap-2"><Printer className="h-4 w-4" />چاپکردن</Button>
          <Button onClick={handleExport} className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white"><FileSpreadsheet className="h-4 w-4" />ئێکسڵ</Button>
          <Button onClick={() => setOpen(true)} className="gap-2"><Plus className="h-4 w-4" />پارەدانی نوێ</Button>
        </div>
      </div>

      <Card className="print-area">
        <CardHeader className="pb-3 border-b bg-slate-50/50 dark:bg-slate-900/50 print:hidden">
          <div className="relative max-w-sm">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input placeholder="گەڕان بە ناوی دابینکار، تێبینی، یان بەروار..." className="pl-3 pr-9" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <div className="hidden print:block text-center py-3 border-b">
            <div className="text-xl font-bold">کارگەی خشتی ماد — پارەدانی دابینکاران</div>
            <div className="text-xs text-slate-500 mt-1" dir="ltr">{new Date().toLocaleDateString("en-GB")}</div>
          </div>
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold w-10">ژ</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold">دابینکار</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold text-center">بەروار</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold text-left">بڕ (د.ع)</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold">تێبینی</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold text-center w-16 print:hidden">کارەکان</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={6} className="border border-slate-300 px-3 py-8 text-center text-slate-500">بەڕێکردن...</td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan={6} className="border border-slate-300 px-3 py-8 text-center text-slate-500">هیچ پارەدانێک نییە</td></tr>
              ) : filtered.map((p, i) => (
                <tr key={p.id} className={i % 2 === 0 ? "bg-white dark:bg-slate-950" : "bg-slate-50 dark:bg-slate-900"}>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-center text-slate-400">{i + 1}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 font-medium">{p.supplierName}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-center tabular-nums" dir="ltr">{formatDate(p.paymentDate)}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-left tabular-nums font-bold text-amber-700" dir="ltr">{(p.amountIqd ?? 0).toLocaleString()}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-slate-500">{p.notes || "—"}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-2 py-1.5 text-center print:hidden">
                    <button onClick={() => del({ id: p.id })} className="inline-flex items-center justify-center p-1.5 rounded-md bg-red-50 text-red-600 hover:bg-red-100 border border-red-100 transition-colors">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
            {filtered.length > 0 && (
              <tfoot>
                <tr className="bg-slate-100 dark:bg-slate-800 font-bold">
                  <td colSpan={3} className="border border-slate-300 dark:border-slate-600 px-3 py-2">کۆی گشتی ({filtered.length})</td>
                  <td className="border border-slate-300 dark:border-slate-600 px-3 py-2 text-left tabular-nums text-amber-700" dir="ltr">{formatMoney(totalPaid)}</td>
                  <td colSpan={2} className="border border-slate-300 dark:border-slate-600 px-3 py-2"></td>
                </tr>
              </tfoot>
            )}
          </table>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>وەسڵی پارەدان بۆ دابینکار</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">دابینکار</Label>
                <select value={form.supplierId} onChange={(e) => setForm({ ...form, supplierId: e.target.value })} className="w-full border rounded px-3 py-2 mt-1 bg-white dark:bg-slate-900 text-sm">
                  <option value="">دابینکار هەڵبژێرە...</option>
                  {suppliers?.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div>
                <Label className="text-xs">قەرز ماوە</Label>
                <Input value={selectedSupplier ? formatMoney(selectedSupplier.totalDebt ?? 0) : "—"} readOnly className="mt-1 bg-slate-50 font-bold text-red-600" dir="ltr" />
              </div>
            </div>
            <div>
              <Label className="text-xs">بڕی پارەی پێدراو (د.ع)</Label>
              <Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="0" className="mt-1 text-xl font-bold h-12" dir="ltr" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-xs">بەروار</Label><Input type="date" value={form.paymentDate} onChange={(e) => setForm({ ...form, paymentDate: e.target.value })} className="mt-1" /></div>
              <div><Label className="text-xs">تێبینی</Label><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="تێبینی..." className="mt-1" /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>هەڵوەشاندنەوە</Button>
            <Button onClick={() => { if (!form.supplierId || !form.amount) return; create({ data: { supplierId: Number(form.supplierId), amount: Number(form.amount), currency: "IQD", paymentDate: form.paymentDate, notes: form.notes || undefined } }); }} disabled={creating || !form.supplierId || !form.amount}>{creating ? "تۆمارکردن..." : "تۆمارکردن"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
