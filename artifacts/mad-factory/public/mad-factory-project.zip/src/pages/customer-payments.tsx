import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { formatMoney } from "@/lib/format";
import { useListCustomerPayments, useCreateCustomerPayment, useDeleteCustomerPayment, useListCustomers, getListCustomerPaymentsQueryKey, getListCustomersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { CreditCard, Plus, Trash2 } from "lucide-react";

export default function CustomerPayments() {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ customerId: "", amount: "", paymentDate: new Date().toISOString().split("T")[0], notes: "" });

  const { data: payments, isLoading } = useListCustomerPayments({}, { query: { queryKey: getListCustomerPaymentsQueryKey({}) } });
  const { data: customers } = useListCustomers({}, { query: { queryKey: getListCustomersQueryKey({}) } });
  const { mutate: create, isPending: creating } = useCreateCustomerPayment({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListCustomerPaymentsQueryKey({}) });
        queryClient.invalidateQueries({ queryKey: ["cashboxSummary"] });
        setOpen(false);
        setForm({ customerId: "", amount: "", paymentDate: new Date().toISOString().split("T")[0], notes: "" });
      },
    },
  });
  const { mutate: deletePayment } = useDeleteCustomerPayment({
    mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListCustomerPaymentsQueryKey({}) }) },
  });

  const totalAmount = (payments ?? []).reduce((s, p) => s + p.amount, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <CreditCard className="h-6 w-6 text-primary" />
          پارەدانی کڕیاران
        </h1>
        <Button onClick={() => setOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          پارەدان تۆمارکردن
        </Button>
      </div>

      <Card>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 text-right font-semibold">ژ</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 text-right font-semibold">کڕیار</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 text-left font-semibold">بڕ (د.ع)</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 text-center font-semibold">بەروار</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 text-right font-semibold">تێبینی</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 w-14"></th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={6} className="border border-slate-300 px-3 py-8 text-center text-slate-500">بەڕێکردن...</td></tr>
              ) : !payments?.length ? (
                <tr><td colSpan={6} className="border border-slate-300 px-3 py-8 text-center text-slate-500">هیچ پارەدانێک نەدۆزرایەوە</td></tr>
              ) : payments.map((p, i) => (
                <tr key={p.id} className={i % 2 === 0 ? "bg-white dark:bg-slate-950" : "bg-slate-50 dark:bg-slate-900"}>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-center text-slate-400">{i + 1}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 font-medium">{p.customerName}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-left tabular-nums font-bold text-emerald-600" dir="ltr">{formatMoney(p.amount)}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-center tabular-nums" dir="ltr">{p.paymentDate}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-slate-500">{p.notes || "—"}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-2 py-1.5 text-center">
                    <button onClick={() => deletePayment({ id: p.id })} className="p-1.5 rounded hover:bg-red-100 dark:hover:bg-red-900 text-destructive transition-colors">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
              {(payments?.length ?? 0) > 0 && (
                <tr className="bg-slate-100 dark:bg-slate-800 font-bold">
                  <td colSpan={2} className="border border-slate-300 dark:border-slate-600 px-3 py-2 text-right">کۆی گشتی ({payments?.length})</td>
                  <td className="border border-slate-300 dark:border-slate-600 px-3 py-2 text-left tabular-nums text-emerald-700" dir="ltr">{formatMoney(totalAmount)}</td>
                  <td colSpan={3} className="border border-slate-300 dark:border-slate-600 px-3 py-2"></td>
                </tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>تۆمارکردنی پارەدان</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>کڕیار</Label>
              <select value={form.customerId} onChange={(e) => setForm({ ...form, customerId: e.target.value })} className="w-full border rounded px-3 py-2 mt-1 bg-white dark:bg-slate-900">
                <option value="">کڕیار هەڵبژێرە...</option>
                {customers?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div><Label>بڕی پارە (د.ع)</Label><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="0" /></div>
            <div><Label>بەروار</Label><Input type="date" value={form.paymentDate} onChange={(e) => setForm({ ...form, paymentDate: e.target.value })} /></div>
            <div><Label>تێبینی</Label><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="تێبینی..." /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>هەڵوەشاندنەوە</Button>
            <Button onClick={() => {
              if (!form.customerId || !form.amount || !form.paymentDate) return;
              create({ data: { customerId: Number(form.customerId), amount: Number(form.amount), paymentDate: form.paymentDate, notes: form.notes || undefined } });
            }} disabled={creating}>{creating ? "تۆمارکردن..." : "تۆمارکردن"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
