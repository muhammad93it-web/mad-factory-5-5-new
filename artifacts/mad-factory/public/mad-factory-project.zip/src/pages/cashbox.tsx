import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatMoney } from "@/lib/format";
import { useGetCashboxSummary, useGetMonthlyReport } from "@workspace/api-client-react";
import { Banknote, TrendingUp, TrendingDown, Wallet, Users, Building2, DollarSign } from "lucide-react";

export default function Cashbox() {
  const today = new Date();
  const [year, setYear] = useState(String(today.getFullYear()));
  const [month, setMonth] = useState(String(today.getMonth() + 1).padStart(2, "0"));

  const { data: summary, isLoading: loadingSummary } = useGetCashboxSummary({}, { query: { queryKey: ["cashboxSummary"] } });
  const { data: monthly, isLoading: loadingMonthly } = useGetMonthlyReport(
    { year: Number(year), month },
    { query: { queryKey: ["monthlyReport", year, month] } }
  );

  const months = [
    { value: "01", label: "کانوونی دووەم" },
    { value: "02", label: "شوبات" },
    { value: "03", label: "ئازار" },
    { value: "04", label: "نیسان" },
    { value: "05", label: "ئایار" },
    { value: "06", label: "حوزەیران" },
    { value: "07", label: "تەمموز" },
    { value: "08", label: "ئاب" },
    { value: "09", label: "ئەیلول" },
    { value: "10", label: "تشرینی یەکەم" },
    { value: "11", label: "تشرینی دووەم" },
    { value: "12", label: "کانوونی یەکەم" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Banknote className="h-6 w-6 text-primary" />
          خەزینە و دارایی
        </h1>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-r-4 border-r-emerald-500">
          <CardContent className="pt-4">
            <div className="text-sm text-slate-500 mb-1">داهاتی فرۆشتن</div>
            <div className="text-xl font-bold text-emerald-600">{formatMoney(summary?.totalSalesRevenue)}</div>
          </CardContent>
        </Card>
        <Card className="border-r-4 border-r-red-500">
          <CardContent className="pt-4">
            <div className="text-sm text-slate-500 mb-1">خەرجی کڕین</div>
            <div className="text-xl font-bold text-red-600">{formatMoney(summary?.totalPurchasesPaid)}</div>
          </CardContent>
        </Card>
        <Card className="border-r-4 border-r-amber-500">
          <CardContent className="pt-4">
            <div className="text-sm text-slate-500 mb-1">خەرجیەکان</div>
            <div className="text-xl font-bold text-amber-600">{formatMoney((summary?.totalExpenses ?? 0) + (summary?.totalPayroll ?? 0))}</div>
          </CardContent>
        </Card>
        <Card className={`border-r-4 ${(summary?.netCash ?? 0) >= 0 ? 'border-r-blue-500' : 'border-r-red-600'}`}>
          <CardContent className="pt-4">
            <div className="text-sm text-slate-500 mb-1">پوختەی خەزینە</div>
            <div className={`text-xl font-bold ${(summary?.netCash ?? 0) >= 0 ? 'text-blue-600' : 'text-red-600'}`}>{formatMoney(summary?.netCash)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Debts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              قەرزی کڕیاران
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{formatMoney(summary?.totalCustomerDebt)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Building2 className="h-4 w-4 text-amber-600" />
              قەرزی دابینکاران
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">{formatMoney(summary?.totalSupplierDebt)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Report */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Wallet className="h-5 w-5 text-primary" />
              ڕاپۆرتی مانگانە
            </span>
            <div className="flex items-center gap-2">
              <select
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                className="border rounded px-2 py-1 text-sm bg-white dark:bg-slate-900"
              >
                {months.map((m) => (
                  <option key={m.value} value={m.value}>{m.label}</option>
                ))}
              </select>
              <Input
                type="number"
                value={year}
                onChange={(e) => setYear(e.target.value)}
                className="w-24 text-center"
                min="2020"
                max="2030"
              />
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loadingMonthly ? (
            <div className="text-center py-8 text-slate-500">بەڕێکردن...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h3 className="font-semibold text-emerald-700 border-b pb-2 flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  داهات و کڕینەوە
                </h3>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">کۆی فرۆشتن</span>
                  <span className="font-bold text-emerald-600">{formatMoney(monthly?.totalSales)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">داهاتی تر</span>
                  <span className="font-bold text-emerald-600">{formatMoney(monthly?.totalOtherIncome)}</span>
                </div>
                <div className="flex justify-between items-center font-semibold border-t pt-2">
                  <span>کۆی داهات</span>
                  <span className="text-emerald-600">{formatMoney((monthly?.totalSales ?? 0) + (monthly?.totalOtherIncome ?? 0))}</span>
                </div>
              </div>
              <div className="space-y-3">
                <h3 className="font-semibold text-red-700 border-b pb-2 flex items-center gap-2">
                  <TrendingDown className="h-4 w-4" />
                  خەرجیەکان
                </h3>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">کۆی کڕین</span>
                  <span className="font-bold text-red-600">{formatMoney(monthly?.totalPurchases)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">خەرجیەکان</span>
                  <span className="font-bold text-red-600">{formatMoney(monthly?.totalExpenses)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">مووچەکان</span>
                  <span className="font-bold text-red-600">{formatMoney(monthly?.totalPayroll)}</span>
                </div>
                <div className="flex justify-between items-center font-semibold border-t pt-2">
                  <span>کۆی خەرجی</span>
                  <span className="text-red-600">{formatMoney((monthly?.totalPurchases ?? 0) + (monthly?.totalExpenses ?? 0) + (monthly?.totalPayroll ?? 0))}</span>
                </div>
              </div>
              <div className={`col-span-2 p-4 rounded-lg ${(monthly?.netProfit ?? 0) >= 0 ? 'bg-emerald-50 border border-emerald-200' : 'bg-red-50 border border-red-200'}`}>
                <div className="flex justify-between items-center">
                  <span className="font-bold text-lg">قازانجی سافی</span>
                  <span className={`text-2xl font-bold ${(monthly?.netProfit ?? 0) >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                    {formatMoney(monthly?.netProfit)}
                  </span>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
