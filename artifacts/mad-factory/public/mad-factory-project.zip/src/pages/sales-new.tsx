import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatMoney } from "@/lib/format";
import { useCreateSalesInvoice, useListCustomers, useListMaterials, getListSalesInvoicesQueryKey, getListCustomersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { ShoppingCart, Plus, Trash2, ArrowRight } from "lucide-react";
import { QuickAddParty } from "@/components/quick-add-party";

type InvoiceItem = {
  materialId: number | null;
  materialName: string;
  quantity: number;
  unitPrice: number;
  palletCount: number | null;
  bricksPerPallet: number | null;
  totalBricks: number | null;
  notes: string;
};

const emptyItem = (): InvoiceItem => ({
  materialId: null,
  materialName: "",
  quantity: 0,
  unitPrice: 0,
  palletCount: null,
  bricksPerPallet: null,
  totalBricks: null,
  notes: "",
});

export default function SalesNew() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();

  const [customerId, setCustomerId] = useState("");
  const [customerMobile, setCustomerMobile] = useState("");
  const [customerAddress, setCustomerAddress] = useState("");
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split("T")[0]);
  const [driver, setDriver] = useState("");
  const [driverMobile, setDriverMobile] = useState("");
  const [vehicle, setVehicle] = useState("");
  const [guarantorName, setGuarantorName] = useState("");
  const [notes, setNotes] = useState("");
  const [discount, setDiscount] = useState(0);
  const [paidAmount, setPaidAmount] = useState(0);
  const [previousDebt, setPreviousDebt] = useState(0);
  const [items, setItems] = useState<InvoiceItem[]>([emptyItem()]);

  const { data: customers } = useListCustomers({}, { query: { queryKey: getListCustomersQueryKey() } });
  const { data: materials } = useListMaterials({}, { query: { queryKey: ["materials"] } });

  const { mutate: create, isPending: creating } = useCreateSalesInvoice({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSalesInvoicesQueryKey({}) });
        queryClient.invalidateQueries({ queryKey: ["cashboxSummary"] });
        navigate("/sales");
      },
    },
  });

  const updateItem = (idx: number, field: keyof InvoiceItem, value: string | number | null) => {
    setItems((prev) => prev.map((item, i) => {
      if (i !== idx) return item;
      let next: InvoiceItem;
      if (field === "materialId") {
        const mat = materials?.find((m) => m.id === Number(value));
        next = {
          ...item,
          materialId: mat?.id ?? null,
          materialName: mat?.name ?? item.materialName,
          unitPrice: mat ? Number(mat.salePrice ?? mat.purchasePrice) : item.unitPrice,
          bricksPerPallet: mat?.bricksPerPallet ?? item.bricksPerPallet,
        };
      } else {
        next = { ...item, [field]: value };
      }
      // Auto-compute totalBricks = palletCount × bricksPerPallet when both set
      if (next.palletCount != null && next.bricksPerPallet != null) {
        next.totalBricks = Number((next.palletCount * next.bricksPerPallet).toFixed(2));
      }
      return next;
    }));
  };

  const addItem = () => setItems((prev) => [...prev, emptyItem()]);
  const removeItem = (idx: number) => setItems((prev) => prev.filter((_, i) => i !== idx));

  const subtotal = items.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
  const total = subtotal - discount;
  const grandTotal = total + previousDebt;
  const remaining = grandTotal - paidAmount;

  const handleSubmit = () => {
    if (!customerId) return;
    create({
      data: {
        customerId: Number(customerId),
        invoiceDate,
        customerMobile: customerMobile || undefined,
        customerAddress: customerAddress || undefined,
        driver: driver || undefined,
        driverMobile: driverMobile || undefined,
        vehicle: vehicle || undefined,
        guarantorName: guarantorName || undefined,
        notes: notes || undefined,
        discount,
        paidAmount,
        previousDebt,
        items: items.filter((i) => i.materialName && i.quantity > 0).map((i) => ({
          materialId: i.materialId ?? undefined,
          materialName: i.materialName,
          quantity: i.quantity,
          unitPrice: i.unitPrice,
          palletCount: i.palletCount ?? undefined,
          bricksPerPallet: i.bricksPerPallet ?? undefined,
          totalBricks: i.totalBricks ?? undefined,
          notes: i.notes || undefined,
        })),
      },
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <ShoppingCart className="h-6 w-6 text-primary" />
          پسووڵەی فرۆشتنی نوێ
        </h1>
        <Button variant="outline" onClick={() => navigate("/sales")} className="gap-2">
          <ArrowRight className="h-4 w-4" />
          گەڕانەوە
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-3 border-b">
            <CardTitle className="text-base">زانیاری کڕیار و پسووڵە</CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-3">
            <div>
              <Label>کڕیار *</Label>
              <div className="flex gap-2 mt-1">
                <select value={customerId} onChange={(e) => setCustomerId(e.target.value)} className="flex-1 border rounded px-3 py-2 bg-white dark:bg-slate-900">
                  <option value="">کڕیار هەڵبژێرە...</option>
                  {customers?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
                <QuickAddParty kind="customer" onCreated={(id) => setCustomerId(String(id))} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>مۆبایلی کڕیار</Label>
                <Input value={customerMobile} onChange={(e) => setCustomerMobile(e.target.value)} placeholder="07XX..." dir="ltr" />
              </div>
              <div>
                <Label>بەروار</Label>
                <Input type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} />
              </div>
            </div>
            <div>
              <Label>ناونیشانی کڕیار</Label>
              <Input value={customerAddress} onChange={(e) => setCustomerAddress(e.target.value)} placeholder="ناونیشان..." />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>شوفێر</Label>
                <Input value={driver} onChange={(e) => setDriver(e.target.value)} placeholder="ناوی شوفێر..." />
              </div>
              <div>
                <Label>مۆبایلی شوفێر</Label>
                <Input value={driverMobile} onChange={(e) => setDriverMobile(e.target.value)} placeholder="07XX..." dir="ltr" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>ئۆتۆمبێل</Label>
                <Input value={vehicle} onChange={(e) => setVehicle(e.target.value)} placeholder="ژمارەی ئۆتۆمبێل..." dir="ltr" />
              </div>
              <div>
                <Label>کەفیل</Label>
                <Input value={guarantorName} onChange={(e) => setGuarantorName(e.target.value)} placeholder="ناوی کەفیل..." />
              </div>
            </div>
            <div>
              <Label>تێبینی</Label>
              <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="تێبینی..." />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3 border-b">
            <CardTitle className="text-base">پوختەی پارەدان</CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-3">
            <div className="flex justify-between items-center py-2">
              <span className="text-slate-600">کۆی پسووڵە:</span>
              <span className="font-bold text-lg">{formatMoney(subtotal)}</span>
            </div>
            <div className="flex items-center gap-3">
              <Label className="shrink-0">داشکاندن:</Label>
              <Input type="number" value={discount || ""} onChange={(e) => setDiscount(Number(e.target.value))} placeholder="0" />
            </div>
            <div className="flex items-center gap-3">
              <Label className="shrink-0">قەرزی پێشوو:</Label>
              <Input type="number" value={previousDebt || ""} onChange={(e) => setPreviousDebt(Number(e.target.value))} placeholder="0" />
            </div>
            <div className="flex justify-between items-center py-2 border-t font-bold">
              <span>کۆی گشتی (پسووڵە + قەرزی پێشوو):</span>
              <span className="text-xl">{formatMoney(grandTotal)}</span>
            </div>
            <div className="flex items-center gap-3">
              <Label className="shrink-0">دراوە:</Label>
              <Input type="number" value={paidAmount || ""} onChange={(e) => setPaidAmount(Number(e.target.value))} placeholder="0" />
            </div>
            <div className={`flex justify-between items-center py-3 px-4 rounded-lg ${remaining > 0 ? 'bg-red-50 border border-red-200' : 'bg-emerald-50 border border-emerald-200'}`}>
              <span className="font-bold">قەرزی ماوە:</span>
              <span className={`font-bold text-xl ${remaining > 0 ? 'text-destructive' : 'text-emerald-600'}`}>{formatMoney(remaining)}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3 border-b">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">بڕگەکانی پسووڵە</CardTitle>
            <Button variant="outline" size="sm" onClick={addItem} className="gap-1">
              <Plus className="h-3 w-3" />
              بڕگەی نوێ
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="space-y-3">
            <div className="grid grid-cols-16 gap-2 text-xs font-medium text-slate-500 px-1" style={{ gridTemplateColumns: "3fr 1fr 1fr 1fr 1fr 1fr 1fr 0.5fr" }}>
              <div>ناوی شت</div>
              <div>بڕ</div>
              <div>پاڵەت</div>
              <div>خشت/پاڵەت</div>
              <div>کۆی خشت</div>
              <div>نرخی یەک</div>
              <div>کۆ</div>
              <div></div>
            </div>
            {items.map((item, idx) => (
              <div key={idx} className="grid gap-2 items-center bg-slate-50 dark:bg-slate-800/50 rounded-lg px-3 py-2" style={{ gridTemplateColumns: "3fr 1fr 1fr 1fr 1fr 1fr 1fr 0.5fr" }}>
                <div>
                  <select
                    value={item.materialId ?? ""}
                    onChange={(e) => {
                      if (e.target.value === "__custom__") updateItem(idx, "materialId", null);
                      else if (e.target.value) updateItem(idx, "materialId", e.target.value);
                    }}
                    className="w-full border rounded px-2 py-1.5 text-sm bg-white dark:bg-slate-900"
                  >
                    <option value="">هەڵبژێرە...</option>
                    {materials?.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
                    <option value="__custom__">--- ناوی دیکە ---</option>
                  </select>
                  {!item.materialId && (
                    <Input placeholder="ناوی شت..." value={item.materialName} onChange={(e) => updateItem(idx, "materialName", e.target.value)} className="mt-1 text-sm h-8" />
                  )}
                </div>
                <div><Input type="number" value={item.quantity || ""} onChange={(e) => updateItem(idx, "quantity", Number(e.target.value))} placeholder="0" className="text-sm h-8" /></div>
                <div><Input type="number" step="0.5" value={item.palletCount ?? ""} onChange={(e) => updateItem(idx, "palletCount", e.target.value ? Number(e.target.value) : null)} placeholder="-" className="text-sm h-8" /></div>
                <div><Input type="number" value={item.bricksPerPallet ?? ""} onChange={(e) => updateItem(idx, "bricksPerPallet", e.target.value ? Number(e.target.value) : null)} placeholder="-" className="text-sm h-8" /></div>
                <div><Input type="number" value={item.totalBricks ?? ""} onChange={(e) => updateItem(idx, "totalBricks", e.target.value ? Number(e.target.value) : null)} placeholder="-" className="text-sm h-8" /></div>
                <div><Input type="number" value={item.unitPrice || ""} onChange={(e) => updateItem(idx, "unitPrice", Number(e.target.value))} placeholder="0" className="text-sm h-8" /></div>
                <div className="text-sm font-bold text-right">{formatMoney(item.quantity * item.unitPrice)}</div>
                <div className="flex justify-end">
                  {items.length > 1 && (
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => removeItem(idx)}>
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end mt-6 gap-3">
            <Button variant="outline" onClick={() => navigate("/sales")}>هەڵوەشاندنەوە</Button>
            <Button onClick={handleSubmit} disabled={creating || !customerId} className="min-w-32">
              {creating ? "تۆمارکردن..." : "پاشەکەوتکردنی پسووڵە"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
