import { useRoute, useLocation } from "wouter";
import { useGetSalesInvoice, getGetSalesInvoiceQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { formatMoney, formatDate } from "@/lib/format";
import { ArrowRight, Printer, FileSpreadsheet } from "lucide-react";
import { exportTableToExcel, buildInvoiceTableHtml } from "@/lib/export";
import { PrintStyles } from "@/components/print-styles";

export default function SalesDetail() {
  const [, params] = useRoute("/sales/:id");
  const [, navigate] = useLocation();
  const id = params?.id ? Number(params.id) : 0;

  const { data: invoice, isLoading } = useGetSalesInvoice(id, {
    query: { enabled: !!id, queryKey: getGetSalesInvoiceQueryKey(id) },
  });

  if (isLoading) return <div className="p-8 text-center text-slate-500">بەڕێکردن...</div>;
  if (!invoice) return <div className="p-8 text-center text-destructive">پسووڵە نەدۆزرایەوە</div>;

  const grandTotal = invoice.total + (invoice.previousDebt ?? 0);

  const handleExport = () => {
    const html = buildInvoiceTableHtml({
      title: `وەسڵی فرۆشتن — ${invoice.invoiceNumber}`,
      meta: [
        ["ژمارەی وەسڵ", invoice.invoiceNumber],
        ["بەروار", formatDate(invoice.invoiceDate)],
        ["کڕیار", invoice.customerName],
        ["مۆبایلی کڕیار", invoice.customerMobile || "-"],
        ["ناونیشان", invoice.customerAddress || "-"],
        ["شۆفێر", invoice.driver || "-"],
        ["مۆبایلی شۆفێر", invoice.driverMobile || "-"],
        ["جۆر و ژمارەی ئۆتۆمبێل", invoice.vehicle || "-"],
        ["کەفیل", invoice.guarantorName || "-"],
        ["تێبینی", invoice.notes || "-"],
      ],
      itemHeaders: ["ژ", "ناوی ماددە", "ژمارەی پالیت", "لە پالیت", "کۆی خشت", "یەکە", "نرخ", "کۆی گشتی"],
      itemRows: invoice.items.map((it, i) => [
        i + 1,
        it.materialName,
        it.palletCount ?? "-",
        it.bricksPerPallet ?? "-",
        it.totalBricks ?? it.quantity,
        it.totalBricks != null ? "خشت" : "-",
        it.unitPrice.toLocaleString(),
        it.total.toLocaleString(),
      ]),
      totals: [
        ["کۆی فرۆشتن", `${invoice.total.toLocaleString()} د.ع`],
        ["قەرزی پێشوو", `${(invoice.previousDebt ?? 0).toLocaleString()} د.ع`],
        ["کۆی گشتی پاش قەرزی پێشوو", `${grandTotal.toLocaleString()} د.ع`],
        ["کۆی پارەدان", `${invoice.paidAmount.toLocaleString()} د.ع`],
        ["باقی قەرز", `${invoice.remainingDebt.toLocaleString()} د.ع`],
      ],
    });
    exportTableToExcel(`${invoice.invoiceNumber}.xls`, html);
  };

  return (
    <div className="space-y-4">
      <PrintStyles />

      {/* Action Bar */}
      <div className="flex items-center justify-between print:hidden">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">وەسڵی فرۆشتن</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => navigate("/sales")} className="gap-2">
            <ArrowRight className="h-4 w-4" /> گەڕانەوە
          </Button>
          <Button variant="outline" onClick={() => window.print()} className="gap-2">
            <Printer className="h-4 w-4" /> چاپکردن
          </Button>
          <Button onClick={handleExport} className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white">
            <FileSpreadsheet className="h-4 w-4" /> ئێکسڵ
          </Button>
        </div>
      </div>

      {/* Invoice Document — matches Mad Brick template */}
      <div className="print-area bg-white border-2 border-slate-300 rounded-lg overflow-hidden text-slate-900" dir="rtl">
        {/* Red header */}
        <div className="bg-white border-b-4 border-red-700">
          <div className="flex items-stretch">
            {/* Logo block */}
            <div className="w-44 bg-white border-l-2 border-red-700 p-2 flex flex-col items-center justify-center">
              <div className="w-16 h-16 bg-red-700 rounded-md flex items-center justify-center text-white font-bold text-xs text-center leading-tight">
                MAD<br/>BRICK
              </div>
              <div className="text-[10px] text-red-700 font-bold mt-1">معمل طابوق ماد</div>
              <div className="text-[9px] text-slate-500 mt-0.5" dir="ltr">0771 153 3480</div>
              <div className="text-[9px] text-slate-500" dir="ltr">0785 153 3480</div>
            </div>
            {/* Title */}
            <div className="flex-1 bg-red-700 text-white py-3 px-4 flex flex-col items-center justify-center">
              <div className="text-2xl font-extrabold">معمل طابوق ماد / کارگەی خشتی ماد</div>
              <div className="text-sm mt-1 opacity-90">بۆ دروستکردنی هەموو جۆرە خشتێک بە تاک و بەکۆ</div>
            </div>
          </div>
          {/* Address row */}
          <div className="flex items-center justify-between bg-white px-4 py-1.5 text-xs border-t border-red-700">
            <div className="font-medium" dir="ltr">07851533480 - 07701533480 - 07511533480 :مۆبایل</div>
            <div className="font-medium">عنوان: ڕێگای جەمجەماڵ - سلێمانی</div>
          </div>
        </div>

        {/* Customer / invoice meta — 3 rows × 4 cells */}
        <div className="border-b border-slate-300">
          <table className="w-full text-sm border-collapse">
            <tbody>
              <tr>
                <th className="bg-slate-100 border border-slate-300 px-2 py-1.5 w-32 text-right">ژمارەی وەسڵ</th>
                <td className="border border-slate-300 px-2 py-1.5 font-bold font-mono" dir="ltr">{invoice.invoiceNumber}</td>
                <th className="bg-slate-100 border border-slate-300 px-2 py-1.5 w-20 text-right">مۆبایل</th>
                <td className="border border-slate-300 px-2 py-1.5" dir="ltr">{invoice.customerMobile || "—"}</td>
                <th className="bg-slate-100 border border-slate-300 px-2 py-1.5 w-24 text-right">تێبینی</th>
                <td className="border border-slate-300 px-2 py-1.5">{invoice.notes || "—"}</td>
                <th className="bg-slate-100 border border-slate-300 px-2 py-1.5 w-20 text-right">بەروار</th>
                <td className="border border-slate-300 px-2 py-1.5" dir="ltr">{formatDate(invoice.invoiceDate)}</td>
              </tr>
              <tr>
                <th className="bg-slate-100 border border-slate-300 px-2 py-1.5 text-right">ناوی کڕیار</th>
                <td className="border border-slate-300 px-2 py-1.5 font-bold">{invoice.customerName}</td>
                <th className="bg-slate-100 border border-slate-300 px-2 py-1.5 text-right">کۆد</th>
                <td className="border border-slate-300 px-2 py-1.5 font-mono" dir="ltr">C-{invoice.customerId.toString().padStart(4, "0")}</td>
                <th className="bg-slate-100 border border-slate-300 px-2 py-1.5 text-right">ناونیشان</th>
                <td className="border border-slate-300 px-2 py-1.5" colSpan={3}>{invoice.customerAddress || "—"}</td>
              </tr>
              <tr>
                <th className="bg-slate-100 border border-slate-300 px-2 py-1.5 text-right">شۆفێر</th>
                <td className="border border-slate-300 px-2 py-1.5">{invoice.driver || "—"}</td>
                <th className="bg-slate-100 border border-slate-300 px-2 py-1.5 text-right">مۆبایلی شۆفێر</th>
                <td className="border border-slate-300 px-2 py-1.5" dir="ltr">{invoice.driverMobile || "—"}</td>
                <th className="bg-slate-100 border border-slate-300 px-2 py-1.5 text-right">جۆر و ژمارەی ئۆتۆمبێل</th>
                <td className="border border-slate-300 px-2 py-1.5" dir="ltr" colSpan={3}>{invoice.vehicle || "—"}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Items table — pallet × bricks-per-pallet → total bricks, then unit/price/total */}
        <div className="p-2">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="bg-emerald-100 text-slate-800 text-xs">
                <th className="border border-slate-300 px-2 py-2 w-10">ژ</th>
                <th className="border border-slate-300 px-2 py-2">ناوی ماددە</th>
                <th className="border border-slate-300 px-2 py-2 w-24">ژمارەی پالیت</th>
                <th className="border border-slate-300 px-2 py-2 w-24">لە پالیت</th>
                <th className="border border-slate-300 px-2 py-2 w-28">کۆی خشت</th>
                <th className="border border-slate-300 px-2 py-2 w-20">یەکە</th>
                <th className="border border-slate-300 px-2 py-2 w-28">نرخ (د.ع)</th>
                <th className="border border-slate-300 px-2 py-2 w-32">کۆی گشتی (د.ع)</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items.length === 0 ? (
                <tr><td colSpan={8} className="border border-slate-300 px-3 py-6 text-center text-slate-400">هیچ بڕگەیەک نییە</td></tr>
              ) : invoice.items.map((it, i) => (
                <tr key={it.id}>
                  <td className="border border-slate-300 px-2 py-1.5 text-center text-slate-500">{i + 1}</td>
                  <td className="border border-slate-300 px-2 py-1.5 font-medium">{it.materialName}</td>
                  <td className="border border-slate-300 px-2 py-1.5 text-center tabular-nums">{it.palletCount?.toLocaleString() ?? "—"}</td>
                  <td className="border border-slate-300 px-2 py-1.5 text-center tabular-nums">{it.bricksPerPallet?.toLocaleString() ?? "—"}</td>
                  <td className="border border-slate-300 px-2 py-1.5 text-center tabular-nums font-semibold">{(it.totalBricks ?? it.quantity).toLocaleString()}</td>
                  <td className="border border-slate-300 px-2 py-1.5 text-center text-xs text-slate-500">{it.totalBricks != null ? "خشت" : "—"}</td>
                  <td className="border border-slate-300 px-2 py-1.5 text-center tabular-nums" dir="ltr">{it.unitPrice.toLocaleString()}</td>
                  <td className="border border-slate-300 px-2 py-1.5 text-center tabular-nums font-bold" dir="ltr">{it.total.toLocaleString()}</td>
                </tr>
              ))}
              {/* Filler rows to match printed layout */}
              {Array.from({ length: Math.max(0, 6 - invoice.items.length) }).map((_, i) => (
                <tr key={`empty-${i}`}>
                  <td className="border border-slate-300 px-2 py-1.5 text-center text-slate-300">{invoice.items.length + i + 1}</td>
                  <td className="border border-slate-300 px-2 py-1.5">&nbsp;</td>
                  <td className="border border-slate-300 px-2 py-1.5">&nbsp;</td>
                  <td className="border border-slate-300 px-2 py-1.5">&nbsp;</td>
                  <td className="border border-slate-300 px-2 py-1.5">&nbsp;</td>
                  <td className="border border-slate-300 px-2 py-1.5">&nbsp;</td>
                  <td className="border border-slate-300 px-2 py-1.5">&nbsp;</td>
                  <td className="border border-slate-300 px-2 py-1.5">&nbsp;</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Totals & notes */}
        <div className="px-2 pb-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2 text-xs text-slate-600 pt-2">
              <div className="font-bold text-slate-700">تێبینی:</div>
              <div className="border border-dashed border-slate-300 rounded p-2 min-h-[80px] whitespace-pre-wrap bg-slate-50">
                {invoice.notes || ""}
              </div>
              <div className="text-[10px] text-slate-500 mt-2">
                هەڵە و لە یادچوون دەگەڕێنرێتەوە بۆ هەردوولا — تێبینی ماددەی فرۆشراو وەرناگیرێت
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="grid grid-cols-2 gap-0">
                <div className="bg-blue-100 border border-slate-300 px-3 py-2 text-sm font-bold text-right">کۆی فرۆشتن</div>
                <div className="border border-slate-300 px-3 py-2 text-left tabular-nums font-bold" dir="ltr">{formatMoney(invoice.total)}</div>
              </div>
              {(invoice.previousDebt ?? 0) > 0 && (
                <div className="grid grid-cols-2 gap-0">
                  <div className="bg-amber-100 border border-slate-300 px-3 py-2 text-sm font-bold text-right">قەرزی پێشوو</div>
                  <div className="border border-slate-300 px-3 py-2 text-left tabular-nums font-bold" dir="ltr">{formatMoney(invoice.previousDebt ?? 0)}</div>
                </div>
              )}
              <div className="grid grid-cols-2 gap-0">
                <div className="bg-emerald-100 border border-slate-300 px-3 py-2 text-sm font-bold text-right">کۆی پارەدان</div>
                <div className="border border-slate-300 px-3 py-2 text-left tabular-nums font-bold text-emerald-700" dir="ltr">{formatMoney(invoice.paidAmount)}</div>
              </div>
              <div className="grid grid-cols-2 gap-0">
                <div className="bg-red-100 border border-slate-300 px-3 py-2 text-sm font-bold text-right">باقی قەرز</div>
                <div className={`border border-slate-300 px-3 py-2 text-left tabular-nums font-bold ${invoice.remainingDebt > 0 ? "text-red-700" : "text-emerald-700"}`} dir="ltr">{formatMoney(invoice.remainingDebt)}</div>
              </div>
            </div>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-3 gap-8 mt-8 pt-4 text-xs text-slate-600">
            <div className="text-center">
              <div className="border-t border-slate-400 pt-1.5">واژۆی فرۆشیار</div>
            </div>
            <div className="text-center">
              <div className="border-t border-slate-400 pt-1.5">واژۆی شۆفێر</div>
            </div>
            <div className="text-center">
              <div className="border-t border-slate-400 pt-1.5">واژۆی کڕیار</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
