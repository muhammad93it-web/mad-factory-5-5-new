import { useState } from "react";
import { useListMaterials, useCreateMaterial, useDeleteMaterial, getListMaterialsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatMoney } from "@/lib/format";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useQueryClient } from "@tanstack/react-query";
import { Package, Plus, Trash2 } from "lucide-react";

export default function Materials() {
  const queryClient = useQueryClient();
  const { data: materials, isLoading } = useListMaterials({}, { query: { queryKey: getListMaterialsQueryKey({}) } });
  const { mutate: create, isPending: creating } = useCreateMaterial({ mutation: { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListMaterialsQueryKey({}) }); setOpen(false); reset(); } } });
  const { mutate: del } = useDeleteMaterial({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListMaterialsQueryKey({}) }) } });

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [unit, setUnit] = useState("خشتە");
  const [purchasePrice, setPurchasePrice] = useState("");
  const [salePrice, setSalePrice] = useState("");
  const [bricksPerPallet, setBricksPerPallet] = useState("");
  const [notes, setNotes] = useState("");

  const reset = () => { setName(""); setUnit("خشتە"); setPurchasePrice(""); setSalePrice(""); setBricksPerPallet(""); setNotes(""); };

  const handleCreate = () => {
    if (!name) return;
    create({ data: { name, unit: unit || undefined, purchasePrice: purchasePrice ? Number(purchasePrice) : 0, salePrice: salePrice ? Number(salePrice) : undefined, bricksPerPallet: bricksPerPallet ? Number(bricksPerPallet) : undefined, notes: notes || undefined } });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Package className="h-6 w-6 text-primary" />کەرەستەکان
        </h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2"><Plus className="h-4 w-4" />زیادکردنی کەرەستە</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md" dir="rtl">
            <DialogHeader><DialogTitle>کەرەستەی نوێ</DialogTitle></DialogHeader>
            <div className="space-y-4 pt-2">
              <div><Label>ناو *</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="ناوی کەرەستە..." /></div>
              <div><Label>یەکە</Label><Input value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="خشتە، تۆن، کیلۆ..." /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>نرخی کڕین (د.ع)</Label><Input type="number" value={purchasePrice} onChange={(e) => setPurchasePrice(e.target.value)} placeholder="0" /></div>
                <div><Label>نرخی فرۆشتن (د.ع)</Label><Input type="number" value={salePrice} onChange={(e) => setSalePrice(e.target.value)} placeholder="0" /></div>
              </div>
              <div>
                <Label>خشت لە هەر پاڵەتێک</Label>
                <Input type="number" value={bricksPerPallet} onChange={(e) => setBricksPerPallet(e.target.value)} placeholder="بۆ نموونە: 1200" />
                <p className="text-xs text-slate-500 mt-1">کاتێک ئەم کەرەستەیە هەڵدەبژێردرێت، خۆکارانە پڕ دەبێتەوە.</p>
              </div>
              <div><Label>تێبینی</Label><Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="تێبینی..." /></div>
              <div className="flex justify-start gap-2 pt-2">
                <Button onClick={handleCreate} disabled={creating || !name}>{creating ? "تۆمارکردن..." : "پاشەکەوتکردن"}</Button>
                <Button variant="outline" onClick={() => { setOpen(false); reset(); }}>پاشگەزبوونەوە</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold">ناوی کەرەستە</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold text-center">یەکە</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold text-left">نرخی کڕین</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold text-left">نرخی فرۆشتن</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold text-center">خشت/پاڵەت</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold">تێبینی</th>
                <th className="border border-slate-300 dark:border-slate-600 px-3 py-2.5 font-semibold text-center w-16">کارەکان</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={7} className="border border-slate-300 px-3 py-8 text-center text-slate-500">بەڕێکردن...</td></tr>
              ) : !materials?.length ? (
                <tr><td colSpan={7} className="border border-slate-300 px-3 py-8 text-center text-slate-500">هیچ کەرەستەیەک نەدۆزرایەوە</td></tr>
              ) : materials.map((m, i) => (
                <tr key={m.id} className={i % 2 === 0 ? "bg-white dark:bg-slate-950" : "bg-slate-50 dark:bg-slate-900"}>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 font-semibold">{m.name}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-center">{m.unit || "—"}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-left tabular-nums" dir="ltr">{m.purchasePrice ? formatMoney(m.purchasePrice) : "—"}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-left tabular-nums" dir="ltr">{m.salePrice ? formatMoney(m.salePrice) : "—"}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-center tabular-nums" dir="ltr">{m.bricksPerPallet ?? "—"}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-3 py-2 text-slate-500">{m.notes || "—"}</td>
                  <td className="border border-slate-300 dark:border-slate-700 px-2 py-1.5 text-center">
                    <button
                      onClick={() => { if (confirm("دڵنیایت لە سڕینەوەی ئەم کەرەستەیە؟")) del({ id: m.id }); }}
                      className="inline-flex items-center justify-center p-1.5 rounded-md bg-red-50 text-red-600 hover:bg-red-100 border border-red-100 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
