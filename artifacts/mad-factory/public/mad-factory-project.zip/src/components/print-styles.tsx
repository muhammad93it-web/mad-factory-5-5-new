export function PrintStyles() {
  return (
    <style>{`
      @media print {
        @page { margin: 1.2cm; size: A4; }
        body { background: white !important; }
        .print\\:hidden { display: none !important; }
        .print-area { box-shadow: none !important; border: none !important; }
        .no-print { display: none !important; }
      }
    `}</style>
  );
}
